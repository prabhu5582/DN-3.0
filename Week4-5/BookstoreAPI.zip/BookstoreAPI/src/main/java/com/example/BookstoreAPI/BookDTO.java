package com.example.BookstoreAPI;
import lombok.Data;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.hateoas.RepresentationModel;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.validation.constraints.Min;

@Data
public class BookDTO extends RepresentationModel<BookDTO>{
    private Long id;
    @NotNull(message = "Title cannot be null")
    @Size(min = 1, max = 100, message = "Title must be between 1 and 100 characters")
    @JsonProperty("book_title")
    private String title;
    @NotNull(message = "Author cannot be null")
    private String author;
    
    @JsonProperty(access = JsonProperty.Access.WRITE_ONLY)
    @Min(value = 0, message = "Price must be greater than or equal to 0")
    private double price;
    @NotNull(message = "ISBN cannot be null")
    private String isbn;
}