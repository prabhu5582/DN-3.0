package com.example.BookstoreAPI;
import com.example.BookstoreAPI.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.transaction.annotation.Transactional;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@Transactional
class BookControllerIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private BookRepository bookRepository;

    @BeforeEach
    void setUp() {
        bookRepository.deleteAll(); // Clear the repository before each test
    }

    @Test
    void createBook_shouldReturnCreatedBook() throws Exception {
        // Arrange
        String bookJson = "{\"title\":\"Spring Boot in Action\",\"author\":\"Craig Walls\",\"price\":40.00,\"isbn\":\"123456789\"}";

        // Act & Assert
        mockMvc.perform(post("/books")
                .contentType(MediaType.APPLICATION_JSON)
                .content(bookJson))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.title").value("Spring Boot in Action"))
                .andExpect(jsonPath("$.author").value("Craig Walls"))
                .andExpect(jsonPath("$.price").value(40.00))
                .andExpect(jsonPath("$.isbn").value("123456789"));
    }
    @Test
    void getBookById_shouldReturnBook() throws Exception {
        BookDTO book = new BookDTO(null, "Spring in Action", "Craig Walls", 40.00, "123456789");
        BookDTO savedBook = bookRepository.save(book);
        mockMvc.perform(get("/books/" + savedBook.getId()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Spring in Action"))
                .andExpect(jsonPath("$.author").value("Craig Walls"))
                .andExpect(jsonPath("$.price").value(40.00))
                .andExpect(jsonPath("$.isbn").value("123456789"));
    }
    @Test
    void updateBook_shouldReturnUpdatedBook() throws Exception {
        BookDTO book = new BookDTO(null, "Spring in Action", "Craig Walls", 40.00, "123456789");
        BookDTO savedBook = bookRepository.save(book);
        String updatedBookJson = "{\"title\":\"Spring Boot in Action\",\"author\":\"Craig Walls\",\"price\":45.00,\"isbn\":\"123456789\"}";
        mockMvc.perform(put("/books/" + savedBook.getId())
                .contentType(MediaType.APPLICATION_JSON)
                .content(updatedBookJson))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.title").value("Spring Boot in Action"))
                .andExpect(jsonPath("$.price").value(45.00));
    }
    @Test
    void deleteBook_shouldReturnNoContent() throws Exception {
        BookDTO book = new BookDTO(null, "Spring in Action", "Craig Walls", 40.00, "123456789");
        BookDTO savedBook = bookRepository.save(book);
        mockMvc.perform(delete("/books/" + savedBook.getId()))
                .andExpect(status().isNoContent());
    }
}