import java.util.ArrayList;
import java.util.List;
public class StockMarket implements Stock{
	private List<Observer> obs;
	private double price;
	public StockMarket() {
		this.obs=new ArrayList<>();
	}
	public void registerObserver(Observer ob) {
		obs.add(ob);
	}
	public void deregisterObserver(Observer ob) {
    	obs.remove(ob);
    }
	public void notifyObservers() {
    	for(Observer ob:obs) {
    		ob.update(price);
    	}
    }
    
    public void setPrice(double price) {
    	this.price=price;
    	notifyObservers();
    }
}