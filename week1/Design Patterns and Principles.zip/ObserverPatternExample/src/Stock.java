public interface Stock {
	void registerObserver(Observer ob);
    void deregisterObserver(Observer ob);
    void notifyObservers();
}
