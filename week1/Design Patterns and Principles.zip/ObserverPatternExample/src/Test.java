public class Test {
	public static void main(String[] args) {
		StockMarket sm1=new StockMarket();
		Observer m1=new MobileApp("MoibleApp");
		Observer w1=new WebApp("WebApp");
		sm1.registerObserver(m1);
		sm1.registerObserver(w1);
		sm1.setPrice(345.67);
		System.out.println(" ");
		sm1.setPrice(456.78);
		System.out.println(" ");
		sm1.deregisterObserver(m1);
		sm1.setPrice(234.56);
		
	}
}
