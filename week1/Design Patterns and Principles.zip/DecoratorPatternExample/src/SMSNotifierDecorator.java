public class SMSNotifierDecorator extends NotifierDecorator{
	public SMSNotifierDecorator(Notifier wrap) {
        super(wrap);
    }
	private void sendSMS(String message) {
        System.out.println("Sending SMS notification: " + message);
    }
	public void send(String message) {
        super.send(message);
        sendSMS(message);
    }
}
