public class SlackNotifierDecorator extends NotifierDecorator{
	public SlackNotifierDecorator(Notifier wrap) {
        super(wrap);
    }
	private void sendSlackMessage(String message) {
        System.out.println("Sending Slack notification: " + message);
    }
	public void send(String message) {
        super.send(message);
        sendSlackMessage(message);
    }
}
