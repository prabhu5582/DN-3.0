public class Test {
	public static void main(String[] args) {
		Notifier n1=new EmailNotifier();
		n1=new SMSNotifierDecorator(n1);
		n1=new SlackNotifierDecorator(n1);
		
		n1.send("It is a test message!");
	}

}
