public class NotifierDecorator implements Notifier{
	protected Notifier wrap;
	public NotifierDecorator(Notifier wrap) {
		this.wrap=wrap;
	}
	public void send(String message) {
		wrap.send(message);
	}
}
