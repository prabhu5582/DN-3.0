public class CustomerService {
	private CustomerRepository cr1;
	public CustomerService(CustomerRepository cr1) {
		this.cr1=cr1;
	}
	public Customer getCustomerById(String id) {
		return cr1.findCustomerById(id);
	}
}
