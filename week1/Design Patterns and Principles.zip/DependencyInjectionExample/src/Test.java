public class Test {
	public static void main(String[] args) {
		 CustomerRepository cr1 = new CustomerRepositoryImpl();
	     CustomerService cs1 = new CustomerService(cr1);
	     Customer c = cs1.getCustomerById("1");
	     System.out.println(c);
	}
}
