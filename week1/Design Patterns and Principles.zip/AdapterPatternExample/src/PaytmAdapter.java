public class PaytmAdapter implements PaymentProcessor {
	private PaytmGateway paytm;
	public PaytmAdapter(PaytmGateway paytm) {
        this.paytm = paytm;
    }
	public void processPayment(double amt) {
        paytm.makePayment(amt);
    }
}
