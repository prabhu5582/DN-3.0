public class PhonePeGateway {
	public void makePayment(double amt) {
        System.out.println("Processing payment of Rs." + amt + " through PhonePe.");
	}
}
