public interface PaymentProcessor {
	void processPayment(double amt);
}
