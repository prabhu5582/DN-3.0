public class Test {
	public static void main(String[] args) {
		PaytmGateway tm1=new PaytmGateway();
		PhonePeGateway pe1=new PhonePeGateway();
		PaymentProcessor tmProcessor=new PaytmAdapter(tm1);
		PaymentProcessor peProcessor=new PhonePeAdapter(pe1);
		tmProcessor.processPayment(3456.78);
		peProcessor.processPayment(1234.56);

	}

}
