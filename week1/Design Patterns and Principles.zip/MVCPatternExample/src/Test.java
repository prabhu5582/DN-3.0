public class Test {
	public static void main(String[] args) {
		Student s1 = new Student();
		s1.setName("Abcd Wxyz");
        s1.setId("1234567890");
        s1.setGrade("B");
        StudentView v1 = new StudentView();
        StudentController c1 = new StudentController(s1, v1);
        c1.updateView();
        c1.setStudentName("Efgh Stuv");
        c1.setStudentGrade("A");
        c1.updateView();
	}
}
