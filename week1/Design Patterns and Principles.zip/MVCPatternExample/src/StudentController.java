public class StudentController {
	 private Student s1;
	 private StudentView v1;
	 public StudentController(Student s1,StudentView v1) {
		 this.s1=s1;
		 this.v1=v1;
	 }
	 public void setStudentName(String name) {
	        s1.setName(name);
	 }
	 public void setStudentId(String id) {
	        s1.setId(id);
	 }
	 public void setStudentGrade(String grade) {
	        s1.setGrade(grade);
	 }
	 public String getStudentName() {
	        return s1.getName();
	 }
	 public String getStudentId() {
	        return s1.getId();
	 }
	 public String getStudentGrade() {
	        return s1.getGrade();
	 }
	 public void updateView() {
	        v1.displayStudentDetails(s1.getName(), s1.getId(), s1.getGrade());
	 }
}
