public class Test {
	public static void main(String[] args) {
    	PaymentContext pc1 = new PaymentContext();
        PaymentStrategy creditCardPayment = new CreditCardPayment("123456789012", "ABCDWXYZ", "123", "11/33");
	    pc1.setPaymentStrategy(creditCardPayment);
        pc1.executePayment(1234.56);
        System.out.println();
	    PaymentStrategy payPalPayment = new PayPalPayment("abcd123@gmail.com", "password123");
	    pc1.setPaymentStrategy(payPalPayment);
	    pc1.executePayment(3456.78);
	}
}
