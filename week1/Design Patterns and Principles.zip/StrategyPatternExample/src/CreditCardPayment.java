public class CreditCardPayment implements PaymentStrategy{
	private String Number;
    private String Name;
    private String cvv;
    private String expiryDate;
    public CreditCardPayment(String Number,String Name,String cvv,String expiryDate) {
    	this.cvv=cvv;
    	this.expiryDate=expiryDate;
    	this.Name=Name;
    	this.Number=Number;
    }
	public void pay(double amt) {
		System.out.println("Paid " + amt + " using Credit Card.");
	}

}
