public interface PaymentStrategy {
	void pay(double amt);
}
