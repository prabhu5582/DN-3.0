public class PaymentContext {
	private PaymentStrategy p1;
	public void setPaymentStrategy(PaymentStrategy p1) {
		this.p1=p1;
	}
	public void executePayment(double amount) {
        p1.pay(amount);
    }
}
