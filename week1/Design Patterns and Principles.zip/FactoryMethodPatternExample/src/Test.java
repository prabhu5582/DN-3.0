
public class Test {
	public static void main(String[] args) {
		DocumentFactory word=new WordDocumentFactory();
		Document w1=word.createDocument();
		w1.open();
		w1.close();
		
		DocumentFactory pdf=new PdfDocumentFactory();
		Document p1=pdf.createDocument();
		p1.open();
		p1.close();
		
		DocumentFactory excel=new ExcelDocumentFactory();
		Document e1=excel.createDocument();
		e1.open();
		e1.close();

	}

}
