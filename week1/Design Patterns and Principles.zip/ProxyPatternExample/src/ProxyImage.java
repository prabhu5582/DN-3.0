public class ProxyImage implements Image{
	private String url;
	private RealImage r1;
	public ProxyImage(String url) {
		this.url=url;
	}
	public void display() {
		if(r1==null) {
			r1=new RealImage(url);
		}
		r1.display();
	}
}
