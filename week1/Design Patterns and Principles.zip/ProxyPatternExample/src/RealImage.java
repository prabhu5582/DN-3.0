public class RealImage implements Image{
	private String url;
	private void loadFromRemoteServer() {
		System.out.println("Loading image from " + url);
	}
	public RealImage(String url) {
		this.url=url;
		loadFromRemoteServer();
	}
	public void display() {
		System.out.println("Displaying image from " + url);
	}
}
