public class Test {
	public static void main(String[] args) {
		Image i1=new ProxyImage("https://www.google.com/url?sa=i&url=https%3A%2F%2Fen.wikipedia.org%2Fwiki%2F2024_Summer_Olympics&psig=AOvVaw11h6KkF2c78pCJbgSYcc9s&ust=1722338588526000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCIDH_q-RzIcDFQAAAAAdAAAAABAE");
		Image i2=new ProxyImage("https://www.google.com/url?sa=i&url=https%3A%2F%2Fwww.mensjournal.com%2Ftravel%2Fon-location-paris-2024-olympic-games&psig=AOvVaw11h6KkF2c78pCJbgSYcc9s&ust=1722338588526000&source=images&cd=vfe&opi=89978449&ved=0CBEQjRxqFwoTCIDH_q-RzIcDFQAAAAAdAAAAABAJ");
		i1.display();
		System.err.println(" ");
		
		i1.display();
		System.err.println(" ");
		
		i2.display();
		System.err.println(" ");
		
		i2.display();
		System.err.println(" ");
	}

}
