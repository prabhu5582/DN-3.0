public class Test {
	public static void main(String[] args) {
		Computer Comp1 = new Computer.Builder("Intel i5", "8GB").build();
        Computer Comp2 = new Computer.Builder("Intel i7", "16GB").storage("1TB SSD").graphicsCard("NVIDIA GTX 3080").hasWiFi(true).build();
        Computer Comp3 = new Computer.Builder("AMD Ryzen 9", "32GB").storage("2TB SSD").graphicsCard("NVIDIA RTX 4090").hasWiFi(true).build();
        
        System.out.println(Comp1.details());
        System.out.println(Comp2.details());
        System.out.println(Comp3.details());
	}

}
