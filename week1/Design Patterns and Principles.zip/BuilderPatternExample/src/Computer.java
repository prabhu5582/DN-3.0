public class Computer {
	private String CPU;
	private String RAM;
	private String storage;
	private String graphicsCard;
	private boolean hasWiFi;
    
	private Computer(Builder builder) {
    	this.CPU = builder.CPU;
        this.RAM = builder.RAM;
        this.storage = builder.storage;
        this.graphicsCard = builder.graphicsCard;
        this.hasWiFi = builder.hasWiFi;
    }
    
    public String details() {
        return "Computer [CPU=" + CPU + ", RAM=" + RAM + 
               (storage != null ? ", Storage=" + storage : "") +
               (graphicsCard != null ? ", GraphicsCard=" + graphicsCard : "") +
               ", HasWiFi=" + hasWiFi + "]";
    }
    public static class Builder {
    	private String CPU;
    	private  String RAM;
    	private String storage;
    	private String graphicsCard;
    	private boolean hasWiFi = false;
        
        public Builder(String CPU, String RAM) {
            this.CPU = CPU;
            this.RAM = RAM;
        }
        
        public Builder storage(String storage) {
            this.storage = storage;
            return this;
        }
        public Builder graphicsCard(String graphicsCard) {
            this.graphicsCard = graphicsCard;
            return this;
        }
        public Builder hasWiFi(boolean hasWiFi) {
            this.hasWiFi = hasWiFi;
            return this;
        }
        
        public Computer build() {
            return new Computer(this);
        }
    }
}
