public class RemoteControl {
	private Command c1;
	public void setCommand(Command c1) {
		this.c1=c1;
	}
	public void pressButton() {
		c1.execute();
	}
}
