public class Test {
	public static void main(String[] args) {
		Light l1=new Light();
		Command lon=new LightOnCommand(l1);
		Command loff=new LightOffCommand(l1);
		RemoteControl r1=new RemoteControl();
		r1.setCommand(lon);
		r1.pressButton();
		System.out.println(" ");
		r1.setCommand(loff);
		r1.pressButton();
	}
}
