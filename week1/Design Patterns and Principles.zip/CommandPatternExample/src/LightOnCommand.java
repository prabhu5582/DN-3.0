public class LightOnCommand implements Command{
	private Light l1;
	public LightOnCommand(Light l1) {
		this.l1=l1;
	}
	public void execute() {
		l1.turnOn();
	}

}
