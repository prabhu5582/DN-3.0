public class LightOffCommand implements Command{
	private Light l1;
	public LightOffCommand(Light l1) {
		this.l1=l1;
	}
	public void execute() {
		l1.turnOff();
	}

}
