public class Test {
	public static void main(String[] args) {
		Inventory i1=new Inventory();
        Product p1=new Product("P001","Laptop",10,999.99);
        Product p2=new Product("P002","Smart Phone",50,599.99);
        i1.add(p1);
        i1.add(p2);
        System.out.println("All products:");
        i1.displayAllProducts();
        i1.update("P001",8,949.99);
        System.out.println("Updated product:");
        System.out.println(i1.getProduct("P001").details());
        i1.delete("P002");
        System.out.println("All products after deletion:");
        i1.displayAllProducts();
	}
}
