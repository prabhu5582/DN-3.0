import java.util.*;
public class Inventory {
	 private Map<String, Product> products;

	    public Inventory() {
	        products = new HashMap<>();
	    }

	    public void add(Product product) {
	        products.put(product.getPro_id(), product);
	    }

	    public void update(String productId, int quantity, double price) {
	        Product product = products.get(productId);
	        if (product != null) {
	            product.setQuantity(quantity);
	            product.setPrice(price);
	        }
	    }

	    public void delete(String productId) {
	        products.remove(productId);
	    }

	    public Product getProduct(String productId) {
	        return products.get(productId);
	    }

	    public void displayAllProducts() {
	        for (Product product : products.values()) {
	            System.out.println(product.details());
	        }
	    }
}
