public class Product {
	private String pro_id;
	private String pro_name;
	private int quantity;
	private double price;
	public Product(String pro_id, String pro_name, int quantity, double price) {
        this.pro_id = pro_id;
	    this.pro_name = pro_name;
        this.quantity = quantity;
        this.price = price;
    }
	public String getPro_id() {
		return pro_id;
	}
	public String getPro_name() {
		return pro_name;
	}
	public int getQuantity() {
		return quantity;
	}
	public double getprice() {
		return price;
	}
	public void setQuantity(int quantity) {
		this.quantity=quantity;
	}
	public void setPrice(double price) {
		this.price=price;
	}
	public String details() {
        return "Product{" +
                "Product Id= " + pro_id +
                ", Product Name= " + pro_name +
                ", Quantity=" + quantity +
                ", Price=" + price +
                '}';
    }
}
