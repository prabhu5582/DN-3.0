public class Task {
	private String task_id;
	private String task_name;
	private String status;
	public Task(String task_id,String task_name,String status) {
		this.status=status;
		this.task_id=task_id;
		this.task_name=task_name;
	}
	public String getTaskId() {
	     return task_id;
	}
	public String getTaskName() {
		return task_name;
	}
	public String getStatus() {
	    return status;
	}
	public String details() {
	    return "Task{ Task ID= " + task_id +
	                ", Task Name= " + task_name +
	                ", Status= " + status +" }";
	}
}
