public class Test {
	public static void main(String[] args) {
		TaskLinkedList taskList = new TaskLinkedList();
        taskList.addTask(new Task("T001", "Design Database", "In Progress"));
        taskList.addTask(new Task("T002", "Develop API", "Not Started"));
        taskList.addTask(new Task("T003", "Create UI", "In Progress"));
        System.out.println("All Tasks:");
        taskList.traverseTasks();
        System.out.println("Searching for task with ID 'T002':");
        Task task = taskList.searchTask("T002");
        if (task != null) {
            System.out.println("Task found: " + task.details());
        } 
        else {
            System.out.println("Task not found.");
        }
        System.out.println("Deleting task with ID 'T002':");
        boolean deleted = taskList.deleteTask("T002");
        if (deleted) {
            System.out.println("Task deleted.");
        } 
        else {
            System.out.println("Task not found.");
        }
        System.out.println("All Tasks after deletion:");
        taskList.traverseTasks();

	}

}
