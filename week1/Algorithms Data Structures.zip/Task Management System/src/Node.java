public class Node {
	 Task task;
     Node next;
     Node(Task t) {
         task=t;
         next=null;
     }
}
