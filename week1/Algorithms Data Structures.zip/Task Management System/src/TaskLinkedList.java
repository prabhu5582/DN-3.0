public class TaskLinkedList {
	private Node head;
    public void addTask(Task t) {
        Node newNode = new Node(t);
        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }
    public Task searchTask(String task_id) {
        Node current = head;
        while (current != null) {
            if (current.task.getTaskId().equals(task_id)) {
                return current.task;
            }
            current = current.next;
        }
        return null;
    }
    public void traverseTasks() {
        Node current = head;
        while (current != null) {
            System.out.println(current.task.details());
            current = current.next;
        }
    }
    public boolean deleteTask(String task_id) {
        if (head == null) {
            return false;
        }
        if (head.task.getTaskId().equals(task_id)) {
            head = head.next;
            return true;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.task.getTaskId().equals(task_id)) {
                current.next = current.next.next;
                return true;
            }
            current = current.next;
        }
        return false;
    }
}
