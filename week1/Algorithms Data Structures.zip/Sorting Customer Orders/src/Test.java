import java.util.*;
public class Test {
	public static void main(String[] args) {
		Order[] orders = {
	            new Order("O001", "Alice", 250.00),
	            new Order("O002", "Bob", 150.00),
	            new Order("O003", "Charlie", 300.00),
	            new Order("O004", "Dave", 200.00),
	            new Order("O005", "Eve", 100.00)
	    };
		System.out.println("Bubble Sort:");
        Order[] bubbleSort = Arrays.copyOf(orders, orders.length);
        BubbleSort.bubbleSort(bubbleSort);
        for (Order o1 : bubbleSort) {
            System.out.println(o1.details());
        }
        System.out.println("Quick Sort:");
        Order[] quickSort = Arrays.copyOf(orders, orders.length);
        QuickSort.quickSort(quickSort, 0, quickSort.length - 1);
        for (Order o2 : quickSort) {
            System.out.println(o2.details());
        }
	}
}
