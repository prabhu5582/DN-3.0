public class Order {
	private String order_id;
	private String cust_name;
	private double total_price;
	public Order(String order_id,String cust_name,double total_price) {
		this.cust_name=cust_name;
		this.order_id=order_id;
		this.total_price=total_price;
	}
	public String getOrder_id() {
        return order_id;
    }

    public String getCust_name() {
        return cust_name;
    }

    public double getTotal_price() {
        return total_price;
    }
    public String details() {
        return "Order{ Order ID= " + order_id +
                ", Customer Name= " + cust_name + 
                ", Total Price=" + total_price+" }" ;
    }
}
