import java.util.*;
public class FinancialForecastingTool1 {
	private static Map<Integer, Double> memo = new HashMap<>();
    public static double predictFutureValue(double initialValue, double growthRate, int years) {
        if (years == 0) {
            return initialValue;
        } else if (memo.containsKey(years)) {
            return memo.get(years);
        } else {
            double futureValue = (1 + growthRate) * predictFutureValue(initialValue, growthRate, years - 1);
            memo.put(years, futureValue);
            return futureValue;
        }
    }
    public static void main(String[] args) {
        double initialValue = 1000.0;
        double growthRate = 0.05;
        int years = 10;
        double futureValue = predictFutureValue(initialValue, growthRate, years);
        System.out.println("Predicted future value after " + years + " years: $" + futureValue);
    }
}
