public class LinearSearch {
	public static Product linearSearch(Product[] products, String productName) {
        for (Product pro : products) {
            if (pro.getPro_name().equalsIgnoreCase(productName)) {
                return pro;
            }
        }
        return null;
    }
}
