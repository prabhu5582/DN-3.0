public class Product {
	private String pro_id;
	private String pro_name;
	private String category;
	public Product(String pro_id, String pro_name, String category) {
        this.pro_id = pro_id;
        this.pro_name = pro_name;
        this.category = category;
    }
	public String getPro_id() {
        return pro_id;
    }
    public String getPro_name() {
        return pro_name;
    }
    public String getCategory() {
        return category;
    }
    public String details() {
    	return "Product{" +
                "Product Id= " + pro_id +
                ", Product Name= " + pro_name +
                ", Category= " + category +
                '}';
	}
}
