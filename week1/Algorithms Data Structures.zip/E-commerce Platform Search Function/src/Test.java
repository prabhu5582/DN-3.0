public class Test {
	public static void main(String[] args) {
		 Product[] products={
				    new Product("P001","Laptop","Electronics"),
		            new Product("P002","Smartphone","Electronics"),
		            new Product("P003","Tablet","Electronics"),
		            new Product("P004","Headphones","Accessories"),
		            new Product("P005","Keyboard","Accessories")
		        };         
		        System.out.println("Linear Search:");
		        Product p1=LinearSearch.linearSearch(products,"Smartphone");
		        System.out.println(p1!=null ?"Product found: "+p1.details():"Product not found");
		        System.out.println("Binary Search:");
		        p1=BinarySearch.binarySearch(products,"Smartphone");
		        System.out.println(p1!=null ?"Product found: "+p1.details():"Product not found");
	}

}
