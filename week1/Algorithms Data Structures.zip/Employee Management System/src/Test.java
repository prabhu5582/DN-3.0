import java.util.*;
public class Test {
	    public static void main(String[] args) {
	        EmployeeManagementSystem ems=new EmployeeManagementSystem(10);
	        ems.addEmployee(new Employee("E001","Alice","Manager",75000));
	        ems.addEmployee(new Employee("E002","Bob","Developer",50000));
	        ems.addEmployee(new Employee("E003","Charlie","Designer",55000));
	        System.out.println("All Employees:");
	        ems.traverseEmployees();
	        System.out.println("Searching for employee with ID 'E002':");
	        Employee emp=ems.searchEmployee("E002");
	        if(emp!=null) {
	            System.out.println("Employee found: "+emp.details());
	        } 
	        else {
	            System.out.println("Employee not found.");
	        }
	        System.out.println("Deleting employee with ID 'E002':");
	        boolean deleted=ems.deleteEmployee("E002");
	        if (deleted) {
	            System.out.println("Employee deleted.");
	        }
	        else {
	            System.out.println("Employee not found.");
	        }
	        System.out.println("All Employees after deletion:");
	        ems.traverseEmployees();
	    }
}
