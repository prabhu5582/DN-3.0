public class Employee {
	private String e_id;
	private String name;
	private String position;
	private double salary;
	public Employee(String e_id,String name,String position,double salary) {
		this.e_id=e_id;
		this.name=name;
		this.position=position;
		this.salary=salary;
	}
	public String getE_id() {
        return e_id;
    }
    public String getName() {
        return name;
    }
    public String getPosition() {
        return position;
    }    
    public double getSalary() {
        return salary;
    }
    public String details() {
        return "Employee{ employeeId= " + e_id +
                ", name='" + name +
                ", position='" + position +
                ", salary=" + salary +" }";
    }
}