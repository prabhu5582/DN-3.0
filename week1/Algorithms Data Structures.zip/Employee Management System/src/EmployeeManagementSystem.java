import java.util.*;
public class EmployeeManagementSystem {
	    private Employee[] employees;
	    private int size;
	    public EmployeeManagementSystem(int c) {
	        employees = new Employee[c];
	        size = 0;
	    }
	    public boolean addEmployee(Employee employee) {
	        if (size < employees.length) {
	            employees[size] = employee;
	            size++;
	            return true;
	        } else {
	            System.out.println("Array is full. Cannot add more employees.");
	            return false;
	        }
	    }
	    public Employee searchEmployee(String e_id) {
	        for (int i = 0; i < size; i++) {
	            if (employees[i].getE_id().equals(e_id)) {
	                return employees[i];
	            }
	        }
	        return null;
	    }
	    public void traverseEmployees() {
	        for (int i = 0; i < size; i++) {
	            System.out.println(employees[i].details());
	        }
	    }
	    public boolean deleteEmployee(String e_id) {
	        for (int i = 0; i < size; i++) {
	            if (employees[i].getE_id().equals(e_id)) {
	                for (int j = i; j < size - 1; j++) {
	                    employees[j] = employees[j + 1];
	                }
	                employees[size - 1] = null;
	                size--;
	                return true;
	            }
	        }
	        return false;
	    }
}