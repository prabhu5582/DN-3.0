public class Book {
	private String book_id;
	private String author;
	private String title;
	public Book(String book_id,String title,String author) {
		this.author=author;
		this.book_id=book_id;
		this.title=title;
	}
	public String getBook_id() {
		return book_id;
	}
	public String getTitle() {
	    return title;
	}
	public String getAuthor() {
		return author;
	}
	public String details() {
	    return "Book{Book ID='" + book_id +", Title='" + title +", Author='" + author +" }";
	}	
}
