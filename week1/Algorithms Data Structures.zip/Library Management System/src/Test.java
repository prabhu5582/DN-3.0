public class Test {
	public static void main(String[] args) {
		Library l1=new Library();
        l1.addBook(new Book("B001","The Great Gatsby","F. Scott Fitzgerald"));
        l1.addBook(new Book("B002","To Kill a Mockingbird","Harper Lee"));
        l1.addBook(new Book("B003","1984","George Orwell"));
        System.out.println("All Books:");
        l1.traverseBooks();
        System.out.println("Searching for '1984' using linear search:");
        Book b1=l1.linearSearchByTitle("1984");
        if(b1!=null) {
            System.out.println("Book found: " +b1.details());
        } 
        else {
            System.out.println("Book not found.");
        }
        System.out.println("Searching for '1984' using binary search:");
        b1=l1.binarySearchByTitle("1984");
        if(b1!=null) {
            System.out.println("Book found: " +b1.details());
        } 
        else {
            System.out.println("Book not found.");
        }
	}
}
