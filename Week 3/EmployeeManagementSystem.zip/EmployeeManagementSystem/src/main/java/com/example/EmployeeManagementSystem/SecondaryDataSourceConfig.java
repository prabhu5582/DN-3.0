package com.example.EmployeeManagementSystem;

public class SecondaryDataSourceConfig {

}
