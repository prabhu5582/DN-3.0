package com.example.EmployeeManagementSystem;
import org.springframework.beans.factory.annotation.Value;

public class EmployeeDTO {
    private Long id;
    private String name;
    private String email;
    private String departmentName;
    private int nameLength;

    public EmployeeDTO(Long id, String name, String email, String departmentName) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.departmentName = departmentName;
        this.nameLength = name.length();
    }
    @Value("#{target.name.length()}")
    public int getNameLength() {
        return nameLength;
    }
}
