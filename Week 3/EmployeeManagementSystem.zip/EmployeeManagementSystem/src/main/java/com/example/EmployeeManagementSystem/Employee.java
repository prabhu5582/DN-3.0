package com.example.EmployeeManagementSystem;
import jakarta.persistence.*;
import jakarta.persistence.Id;
import lombok.Data;
import lombok.NoArgsConstructor;

import org.springframework.data.annotation.*;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;
import java.time.LocalDateTime;

import org.hibernate.annotations.NaturalId;
import org.hibernate.annotations.Type;
import org.hibernate.annotations.TypeDef;
import org.hibernate.annotations.Parameter;

import javax.persistence.*;

@Data
@NoArgsConstructor
@Entity
@Table(name = "employees")
@EntityListeners(AuditingEntityListener.class)
@TypeDef(name = "json", typeClass = JsonStringType.class)
@NamedQueries({
    @NamedQuery(
        name = "Employee.findByDepartmentNameNamedQuery",
        query = "SELECT e FROM Employee e WHERE e.department.name = :departmentName"
    ),
    @NamedQuery(
        name = "Employee.findEmployeesWithSalaryAboveNamedQuery",
        query = "SELECT e FROM Employee e WHERE e.salary > :salary"
    )
})
public class Employee {
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private Long id;
     @Column(nullable = false)
     private String name;
     @Column(nullable = false, unique = true)
     private String email;
     @ManyToOne(fetch = FetchType.LAZY)
     @JoinColumn(name = "department_id")
     private Department dept;
     @Column(nullable = false)
     private Double salary;
     @CreatedDate
     @Column(updatable = false)
     private LocalDateTime createdDate;
     @LastModifiedDate
     private LocalDateTime lastModifiedDate;
     @CreatedBy
     @Column(updatable = false)
     private String createdBy;
     @LastModifiedBy
     private String lastModifiedBy;
     @NaturalId
     @Column(name = "employee_code", unique = true)
     private String employeeCode;
}
