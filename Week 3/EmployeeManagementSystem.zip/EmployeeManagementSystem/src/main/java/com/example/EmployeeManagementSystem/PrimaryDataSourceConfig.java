package com.example.EmployeeManagementSystem;

public class PrimaryDataSourceConfig {

}
