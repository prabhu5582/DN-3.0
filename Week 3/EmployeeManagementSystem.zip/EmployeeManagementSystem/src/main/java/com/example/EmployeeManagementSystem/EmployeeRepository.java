package com.example.EmployeeManagementSystem;
import com.example.EmployeeManagementSystem.Employee;
import com.example.EmployeeManagementSystem.EmployeeDTO;
import com.example.EmployeeManagementSystem.EmployeeBasicInfo;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	List<Employee> findByName(String name);
    Employee findByEmail(String email);
    List<Employee> findByDepartmentId(Long departmentId);
    
    List<Employee> findByNameContaining(String keyword);
    List<Employee> findByEmailEndingWith(String domain);
    List<Employee> findByDepartmentName(String departmentName);
    
    @Query(name = "Employee.findByDepartmentNameNamedQuery")
    List<Employee> findByDepartmentNameNamed(@Param("departmentName") String departmentName);
    @Query(name = "Employee.findEmployeesWithSalaryAboveNamedQuery")
    List<Employee> findEmployeesWithSalaryAboveNamed(@Param("salary") Double salary);
    
    Page<Employee> findAll(Pageable pageable);
    Page<Employee> findByDepartmentName(String departmentName, Pageable pageable);
    
    List<EmployeeBasicInfo> findAllBy();
    List<EmployeeBasicInfo> findByDepartmentName(String departmentName);
    
    @Query("SELECT new com.example.EmployeeManagementSystem.dto.EmployeeDTO(e.id, e.name, e.email, d.name) "+"FROM Employee e JOIN e.department d")
     List<EmployeeDTO> findEmployeeDTOs();
     @Query("SELECT new com.example.EmployeeManagementSystem.dto.EmployeeDTO(e.id, e.name, e.email, d.name) "+"FROM Employee e JOIN e.department d WHERE d.name = :departmentName")
     List<EmployeeDTO> findEmployeeDTOsByDepartmentName(String departmentName);
}
