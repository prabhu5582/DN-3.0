package com.example.EmployeeManagementSystem;
import com.example.EmployeeManagementSystem.Department;
import org.springframework.data.jpa.repository.*;
import org.springframework.data.repository.query.Param;
import java.util.*;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
    Optional<Department> findByName(String name);
    
    @Query("SELECT d FROM Department d WHERE d.name LIKE %:name%")
    List<Department> findByNameLike(@Param("name") String name);
    @Query(value = "SELECT d.* FROM departments d WHERE (SELECT COUNT(*) FROM employees e WHERE e.department_id = d.id) >= :minEmployees", nativeQuery = true)
    List<Department> findDepartmentsWithMinEmployees(@Param("minEmployees") Long minEmployees);
}
