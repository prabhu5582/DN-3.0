package com.example.EmployeeManagementSystem;
import com.example.EmployeeManagementSystem.Employee;
import com.example.EmployeeManagementSystem.EmployeeRepository;
import com.example.EmployeeManagementSystem.Department;
import com.example.EmployeeManagementSystem.DepartmentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
@Service
public class EmployeeDepartmentService {
    @Autowired
    private EmployeeRepository employeeRepository;
    @Autowired
    private DepartmentRepository departmentRepository;
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }
    public List<Department> getAllDepartments() {
        return departmentRepository.findAll();
    }
}
