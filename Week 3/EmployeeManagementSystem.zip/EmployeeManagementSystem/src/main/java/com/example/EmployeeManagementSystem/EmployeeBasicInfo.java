package com.example.EmployeeManagementSystem;
public class EmployeeBasicInfo {
    Long getId();
    String getName();
    String getEmail();
}
