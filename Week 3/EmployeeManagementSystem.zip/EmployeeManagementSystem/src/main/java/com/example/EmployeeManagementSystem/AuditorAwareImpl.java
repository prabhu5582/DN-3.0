package com.example.EmployeeManagementSystem;
import org.springframework.context.annotation.*;
import org.springframework.data.domain.AuditorAware;
import java.util.*;
public class AuditorAwareImpl implements AuditorAware<String>{
	 @Override
	 public Optional<String> getCurrentAuditor() {
	        return Optional.of("admin");
	 }
	 @Bean
	 public AuditorAware<String> auditorProvider() {
	       return new AuditorAwareImpl();
	 }
}
