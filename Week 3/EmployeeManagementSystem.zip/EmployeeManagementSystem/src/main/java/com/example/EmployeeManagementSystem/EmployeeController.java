package com.example.EmployeeManagementSystem;
import com.example.EmployeeManagementSystem.Employee;
import com.example.EmployeeManagementSystem.EmployeeDTO;
import com.example.EmployeeManagementSystem.EmployeeBasicInfo;
import com.example.EmployeeManagementSystem.EmployeeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.*;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {
    @Autowired
    private EmployeeRepository empRepository;
    @PostMapping
    public Employee createEmployee(@RequestBody Employee employee) {
        return empRepository.save(employee);
    }
    @GetMapping
    public List<Employee> getAllEmployees() {
        return empRepository.findAll();
    }
    @GetMapping("/{id}")
    public ResponseEntity<Employee> getEmployeeById(@PathVariable Long id) {
        Optional<Employee> employee = empRepository.findById(id);
        if (employee.isPresent()) {
            return ResponseEntity.ok(employee.get());
        } 
        else {
            return ResponseEntity.notFound().build();
        }
    }
    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employeeDetails) {
        Optional<Employee> optionalEmployee = empRepository.findById(id);
        if (optionalEmployee.isPresent()) {
            Employee employee = optionalEmployee.get();
            employee.setName(employeeDetails.getName());
            employee.setEmail(employeeDetails.getEmail());
            employee.setDepartment(employeeDetails.getDepartment());
            final Employee updatedEmployee = empRepository.save(employee);
            return ResponseEntity.ok(updatedEmployee);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
        Optional<Employee> employee = empRepository.findById(id);
        if (employee.isPresent()) {
            empRepository.delete(employee.get());
            return ResponseEntity.noContent().build();
        } else {
            return ResponseEntity.notFound().build();
        }
    }
    public Page<Employee> getAllEmployees(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id,asc") String[] sort) {
        Sort.Direction direction = Sort.Direction.fromString(sort[1]);
        Sort sortOrder = Sort.by(direction, sort[0]);
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        
        return empRepository.findAll(pageable);
    }
    @GetMapping("/department")
    public Page<Employee> getEmployeesByDepartment(
            @RequestParam String departmentName,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "id,asc") String[] sort) {
        Sort.Direction direction = Sort.Direction.fromString(sort[1]);
        Sort sortOrder = Sort.by(direction, sort[0]);
        Pageable pageable = PageRequest.of(page, size, sortOrder);
        
        return empRepository.findByDepartmentName(departmentName, pageable);
    }
    @GetMapping("/basic-info")
    public List<EmployeeBasicInfo> getEmployeeBasicInfo() {
        return empRepository.findAllBy();
    }
    @GetMapping("/dto")
    public List<EmployeeDTO> getEmployeeDTOs() {
        return empRepository.findEmployeeDTOs();
    }
    @GetMapping("/dto/by-department")
    public List<EmployeeDTO> getEmployeeDTOsByDepartmentName(@RequestParam String departmentName) {
        return empRepository.findEmployeeDTOsByDepartmentName(departmentName);
    }
}
