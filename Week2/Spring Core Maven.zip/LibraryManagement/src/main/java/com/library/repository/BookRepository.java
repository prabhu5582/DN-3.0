package com.library.repository;

public class BookRepository {
    public void perform() {
        System.out.println("Repository operation is being performed.");
    }
}
