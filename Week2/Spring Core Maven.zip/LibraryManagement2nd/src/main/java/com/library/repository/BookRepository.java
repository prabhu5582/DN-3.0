package com.library.repository;
import org.springframework.stereotype.Repository;

@Repository
public class BookRepository {
    public void perform() {
        System.out.println("Repository operation is being performed.");
    }
}
