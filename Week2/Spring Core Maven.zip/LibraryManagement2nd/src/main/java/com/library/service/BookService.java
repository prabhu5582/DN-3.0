package com.library.service;
import com.library.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class BookService {
    private BookRepository bookRepository;
    
//   @Autowired
//   public void setBookRepository(BookRepository bookRepository) {
//       this.bookRepository = bookRepository;
//   }
    
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
        System.out.println("Constructor injection: BookRepository injected.");
    }

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
        System.out.println("Setter injection: BookRepository injected.");
    }
    
    public void performService() {
        System.out.println("Service is being performed.");
        bookRepository.perform();
    }
}